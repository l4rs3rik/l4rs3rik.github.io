===================================
DarkBox skin for AudioRealism ABL3
===================================

Download: http://bit.ly/abl3-darkbox-skin

Installation: 
-------------
Copy and replace the files in the Gfx folder of your ABL3 installation. It's a good idea to backup the original contents of the Gfx folder if you want to switch back to the original skin. 

Default path to ABL3 installation folder:

PC:
	C:\Users\<your user name>\Documents\AudioRealism\ABL3\

MAC OS:
	/Library/Application Support/AudioRealism/ABL3/


Lars-Erik Johansson
larserikjohansson@hotmail.com


Revision history:
	2017-06-22 [1.0.0] - First version

